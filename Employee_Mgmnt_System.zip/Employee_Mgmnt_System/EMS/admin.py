from django.contrib import admin
from .models import Add_Employee
class EmpAdmin(admin.ModelAdmin):
     
    list_display=('firstname','lastname')
    # list_editable=('firstname','lastname')
    search_fields=('firstname',)

admin.site.register(Add_Employee,EmpAdmin)
# Register your models here.

