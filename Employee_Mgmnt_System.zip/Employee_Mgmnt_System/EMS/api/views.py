from EMS.api.serializer import StaffSerializer
from EMS.models import Add_Employee
from rest_framework import viewsets
class StaffViews(viewsets.ModelViewSet):
    
    queryset = Add_Employee.objects.all()
    serializer_class = StaffSerializer