from rest_framework import serializers
from EMS.models import Add_Employee
class StaffSerializer(serializers.ModelSerializer):
    
    class Meta:
        
        model = Add_Employee
        
        fields = '__all__'